﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace IO.Modules.Volunteer
{
    public class VolunteerManager
    {
        private List<Volunteer> volunteerList;
        private List<Organisation> organisationList;

        public VolunteerManager()
        {
            this.volunteerList = new List<Volunteer>();
            this.organisationList = new List<Organisation>();
            //LoadVolunteersFromFile("volunteers.txt");
        }

        public void addOrganisation(Organisation organisation)
        {
            if (organisation == null)
                throw new ArgumentNullException(nameof(organisation), "Organisation cannot be null.");


            if (organisation.getOrganisationID() == 0 && organisationList.Count != 0)
            {
                organisation.setOrganisationID(organisationList.Last().getOrganisationID() + 1);
            }
            bool flag = false;
            foreach (Organisation org in organisationList)
            {
                if (org.getOrganisationID() == organisation.getOrganisationID())
                {
                    flag = true;
                    break;
                }
            }

            if (!flag)
            {
                organisationList.Add(organisation);
            }
            else
            {
                throw new InvalidOperationException($"Organisation with ID {organisation.getOrganisationID()} already exists.");
            }
        }


        public void addVolunteer(Volunteer volunteer)
        {

            if (volunteer == null)
            {
                throw new ArgumentNullException(nameof(volunteer), "Volunteer cannot be null.");
            }
            Organisation organisation = volunteer.getOrganisation();
            if (organisation == null)
            {
                throw new ArgumentNullException(nameof(organisation), "Organisation cannot be null.");
            }

            if (volunteer.getVolunteerID() == 0 && volunteerList.Count != 0)
            {
                volunteer.setVolunteerID(volunteerList.Last().getVolunteerID() + 1);
            }

            if (volunteerList.Any(v => v.getVolunteerID() == volunteer.getVolunteerID()))
            {
                throw new InvalidOperationException($"Volunteer with ID {volunteer.getVolunteerID()} already exists.");
            }
            else if (!organisationList.Contains(organisation))
            {
                throw new InvalidOperationException("Organisation not found.");
            }
            else
            {
                organisation.addVolunteer(volunteer);
                volunteerList.Add(volunteer);
            }

        }


        public Organisation findOrganisationByID(int organisationID)
        {
            return organisationList.FirstOrDefault(o => o.getOrganisationID() == organisationID);
        }

        public void removeVolunteer(int volunteerID)
        {
            var volunteerToRemove = volunteerList.FirstOrDefault(v => v.getVolunteerID() == volunteerID);

            if (volunteerToRemove == null)
                throw new KeyNotFoundException($"Volunteer with ID {volunteerID} not found.");

            volunteerList.Remove(volunteerToRemove);
        }

        public Volunteer findVolunteerByID(int volunteerID)
        {
            return volunteerList.FirstOrDefault(v => v.getVolunteerID() == volunteerID);
        }

        public int getVolunteerCount()
        {
            return volunteerList.Count;
        }

        public int getOrganisationCount()
        {
            return organisationList.Count;
        }

        public List<Organisation> getOrganisationList()
        {
            return organisationList;
        }



        public string saveManager()
        {
            string all = string.Empty, volunteers = string.Empty, organisations = string.Empty;

            // Iteration over the organisation list
            foreach (Organisation org in organisationList)
            {
                organisations += "\nOrganisation Details:" +
                                 "\nID: " + org.getOrganisationID() +
                                 "\nName: " + org.getOrganisationName() +
                                 "\nPhone: " + new string(org.getPhoneNumber()) +
                                 "\nAddress: " + org.getAddress() +
                                 "\n\n";

                // Add volunteers associated with the organisation
                foreach (Volunteer vol in org.getVolunteerList())
                {
                    volunteers += "\nVolunteer Details:" +
                                  "\nID: " + vol.getVolunteerID() +
                                  "\nName: " + vol.getFirstName() + " " + vol.getLastName() +
                                  "\nEmail: " + vol.getEmail() +
                                  "\nGender: " + vol.getGender() +
                                  "\nPhone: " + new string(vol.getPhoneNumber()) +
                                  "\nAddress: " + vol.getAddress() +
                                  "\nExperience: " + vol.getExperience() +
                                  "\nAdditional Info: " + vol.getAdditionalInfo() +
                                  "\nSkills: " + vol.getSkills() +
                                  "\nAvailability: " + string.Join(", ", vol.getAvailability().Select(a => a.ToString("yyyy-MM-dd"))) +
                                  "\nOrganisation ID: " + org.getOrganisationID() +
                                  "\n\n";
                }
            }

            // Combine organisation and volunteer data
            all = organisations + volunteers;
            return all;
        }

        public void loadManager(string filePath)
        {
            if (!File.Exists(filePath))
                throw new FileNotFoundException($"The file at {filePath} does not exist.");

            var lines = File.ReadAllLines(filePath);
            Volunteer currentVolunteer = null;
            Organisation currentOrganisation = null;

            foreach (var line in lines)
            {
                var trimmedLine = line.Trim();

                // Handle organisation parsing
                if (trimmedLine.StartsWith("Organisation Details:"))
                {
                    if (currentOrganisation != null)
                        this.addOrganisation(currentOrganisation); // Add previous organisation if exists

                    currentOrganisation = new Organisation("", new char[] { }, "");
                }
                else if (trimmedLine.StartsWith("ID:") && currentOrganisation != null)
                {
                    currentOrganisation.setOrganisationID(int.Parse(trimmedLine.Substring(4)));
                }
                else if (trimmedLine.StartsWith("Name:") && currentOrganisation != null)
                {
                    currentOrganisation.setOrganisationName(trimmedLine.Substring(6));
                }
                else if (trimmedLine.StartsWith("Phone:") && currentOrganisation != null)
                {
                    currentOrganisation.setPhoneNumber(trimmedLine.Substring(7).ToCharArray());
                }
                else if (trimmedLine.StartsWith("Address:") && currentOrganisation != null)
                {
                    currentOrganisation.setAddress(trimmedLine.Substring(9));
                }

                // Handle volunteer parsing
                else if (trimmedLine.StartsWith("Volunteer Details:"))
                {
                    if (currentVolunteer != null && currentOrganisation != null)
                        this.addVolunteer(currentVolunteer);

                    currentVolunteer = new Volunteer("", "", "", Gender.Female, new char[] { }, "", "", "", "", new List<DateTime>(), currentOrganisation);
                }
                else if (trimmedLine.StartsWith("ID:") && currentVolunteer != null)
                {
                    currentVolunteer.setVolunteerID(int.Parse(trimmedLine.Substring(4)));
                }
                else if (trimmedLine.StartsWith("Name:") && currentVolunteer != null)
                {
                    var nameParts = trimmedLine.Substring(6).Split(' ');
                    currentVolunteer.setFirstName(nameParts[0]);
                    currentVolunteer.setLastName(nameParts.Length > 1 ? nameParts[1] : "");
                }
                else if (trimmedLine.StartsWith("Email:") && currentVolunteer != null)
                {
                    currentVolunteer.setEmail(trimmedLine.Substring(7));
                }
                else if (trimmedLine.StartsWith("Gender:") && currentVolunteer != null)
                {
                    Enum.TryParse(trimmedLine.Substring(8), out Gender gender);
                    currentVolunteer.setGender(gender);
                }
                else if (trimmedLine.StartsWith("Phone:") && currentVolunteer != null)
                {
                    currentVolunteer.setPhoneNumber(trimmedLine.Substring(7).ToCharArray());
                }
                else if (trimmedLine.StartsWith("Address:") && currentVolunteer != null)
                {
                    currentVolunteer.setAddress(trimmedLine.Substring(9));
                }
                else if (trimmedLine.StartsWith("Experience:") && currentVolunteer != null)
                {
                    currentVolunteer.setExperience(trimmedLine.Substring(12));
                }
                else if (trimmedLine.StartsWith("Additional Info:") && currentVolunteer != null)
                {
                    currentVolunteer.setAdditionalInfo(trimmedLine.Substring(17));
                }
                else if (trimmedLine.StartsWith("Skills:") && currentVolunteer != null)
                {
                    currentVolunteer.setSkills(trimmedLine.Substring(8));
                }
                else if (trimmedLine.StartsWith("Availability:") && currentVolunteer != null)
                {
                    var dates = trimmedLine.Substring(14).Split(", ").Select(DateTime.Parse).ToList();
                    currentVolunteer.setAvailability(dates);
                }
            }

            // Add the last organisation if exists
            if (currentOrganisation != null)
            {
                this.addOrganisation(currentOrganisation);
            }
        }


    }
}
    
